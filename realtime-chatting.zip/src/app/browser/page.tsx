'use client'

import { useEffect } from 'react'
import { useChatStore } from '@/store/chat-store'
import { wsManager } from '@/lib/websocket'
import { ChatHeader } from '@/components/chat/ChatHeader'
import { MessageList } from '@/components/chat/MessageList'
import { MessageInput } from '@/components/chat/MessageInput'
import { Users } from 'lucide-react'
import { Avatar } from '@/components/ui/avatar'

export default function BrowserPage() {
  const { setCurrentUser, setOnlineUsers, addMessage, setConnectionStatus, onlineUsers } = useChatStore()

  useEffect(() => {
    // Initialize current user
    const user = {
      id: 'user-1',
      name: '나',
      isOnline: true
    }
    setCurrentUser(user)

    // Set mock online users
    setOnlineUsers([
      user,
      { id: 'user-2', name: '김철수', isOnline: true },
      { id: 'user-3', name: '박영희', isOnline: true },
    ])

    // Connect to WebSocket
    wsManager.connect()

    // Listen for messages
    const unsubscribeMessage = wsManager.onMessage((message) => {
      addMessage(message)
    })

    // Listen for connection status
    const unsubscribeStatus = wsManager.onStatus((status) => {
      setConnectionStatus(status as any)
    })

    return () => {
      unsubscribeMessage()
      unsubscribeStatus()
      wsManager.disconnect()
    }
  }, [setCurrentUser, setOnlineUsers, addMessage, setConnectionStatus])

  return (
    <div className="flex h-screen bg-background">
      {/* Main chat area */}
      <div className="flex flex-col flex-1">
        <ChatHeader title="실시간 채팅" className="shrink-0" />

        <div className="flex-1 overflow-hidden">
          <MessageList />
        </div>

        <div className="shrink-0">
          <MessageInput />
        </div>
      </div>

      {/* Sidebar - Desktop only */}
      <div className="hidden lg:flex lg:w-64 xl:w-80 flex-col border-l bg-muted/20">
        <div className="flex items-center gap-2 px-4 py-3 border-b">
          <Users className="h-5 w-5 text-primary" />
          <h2 className="font-semibold">접속자 ({onlineUsers.length})</h2>
        </div>

        <div className="flex-1 overflow-auto p-4">
          <div className="space-y-2">
            {onlineUsers.map((user) => (
              <div key={user.id} className="flex items-center gap-3 p-2 rounded-lg hover:bg-muted transition-colors">
                <div className="relative">
                  <Avatar fallback={user.name[0]} className="h-10 w-10" />
                  {user.isOnline && (
                    <div className="absolute bottom-0 right-0 h-3 w-3 rounded-full bg-green-500 ring-2 ring-background" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{user.name}</p>
                  <p className="text-xs text-muted-foreground">온라인</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
