'use client'

import { useEffect } from 'react'
import { useChatStore } from '@/store/chat-store'
import { wsManager } from '@/lib/websocket'
import { ChatHeader } from '@/components/chat/ChatHeader'
import { MessageList } from '@/components/chat/MessageList'
import { MessageInput } from '@/components/chat/MessageInput'

export default function WebViewPage() {
  const { setCurrentUser, setOnlineUsers, addMessage, setConnectionStatus } = useChatStore()

  useEffect(() => {
    // Initialize current user
    const user = {
      id: 'user-1',
      name: '나',
      isOnline: true
    }
    setCurrentUser(user)

    // Set mock online users
    setOnlineUsers([
      user,
      { id: 'user-2', name: '김철수', isOnline: true },
      { id: 'user-3', name: '박영희', isOnline: true },
    ])

    // Connect to WebSocket
    wsManager.connect()

    // Listen for messages
    const unsubscribeMessage = wsManager.onMessage((message) => {
      addMessage(message)
    })

    // Listen for connection status
    const unsubscribeStatus = wsManager.onStatus((status) => {
      setConnectionStatus(status as any)
    })

    return () => {
      unsubscribeMessage()
      unsubscribeStatus()
      wsManager.disconnect()
    }
  }, [setCurrentUser, setOnlineUsers, addMessage, setConnectionStatus])

  return (
    <div className="flex flex-col h-screen bg-background">
      {/* Mobile-optimized header */}
      <ChatHeader title="채팅" className="shrink-0" />

      {/* Message area */}
      <div className="flex-1 overflow-hidden">
        <MessageList />
      </div>

      {/* Input area - fixed at bottom */}
      <div className="shrink-0">
        <MessageInput />
      </div>
    </div>
  )
}
